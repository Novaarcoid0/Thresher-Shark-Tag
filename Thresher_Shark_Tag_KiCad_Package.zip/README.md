# Thresher Shark Tag — KiCad starter package

## Files
- `Thresher_Shark_Tag.kicad_pcb` — 90 x 55 mm placement/connector PCB starter with four provisional 3.2 mm mounting holes.
- `Thresher_Shark_Tag.kicad_sch` — schematic notes / system-interface overview.
- `Thresher_Shark_Tag.kicad_pro` — KiCad project settings.
- `Thresher_Shark_Tag_BOM.csv` — starter bill of materials.
- `STL_measurements.txt` — measured outer mesh bounds and fit caveats.

## Critical status
This is **not fabrication-ready**. The PCB is a placement and connector-layout starting point; it has no routed copper, and the Arduino Nano pads are deliberately left electrically unassigned rather than guessing pin-level mapping. The schematic is an annotated interface overview, not a complete electrical schematic.

The uploaded STL is a watertight mesh with three disconnected components. Its overall bounds are approximately 194 x 190 x 68.01 mm, but the two major shell-like components are positioned separately in the STL coordinate system. Outer bounds alone do not prove the internal cavity, wall thickness, bosses, or final assembled orientation. The 90 x 55 mm board is smaller than the outer envelope, but **internal clearance and hole alignment still need to be checked in the intended assembled casing** before claiming fit or ordering boards.

## Electrical cautions
- Use a classic Arduino Nano ATmega328P, not Nano ESP32.
- GPS NEO-6M generally cannot obtain a satellite fix underwater; it needs an antenna with sky visibility.
- A bare electret microphone capsule must not be connected directly to an analog pin; J4 is for an amplified microphone module.
- The PulseSensor is designed for human pulse sensing and is not validated for underwater shark measurements.
- Do not feed a hydroelectric generator directly into the Nano or SD module. Measure the generator output under load and provide appropriate rectification (if AC), overvoltage protection, energy storage, and regulated power.
- Confirm every module's voltage tolerance and pin order before wiring. Some SD modules have onboard regulators/level shifting, but not all do.

## Before fabrication
1. Open the project in KiCad and run ERC/DRC.
2. Import or align the STL in a mechanical CAD tool, orient the two shell halves as assembled, and verify board clearance plus connector/cable access.
3. Measure mounting bosses and replace provisional mounting-hole coordinates.
4. Confirm Nano header footprint and pin order against the exact board.
5. Add the missing power-conditioning circuit and all required traces, then run DRC and 3D clearance checks.
